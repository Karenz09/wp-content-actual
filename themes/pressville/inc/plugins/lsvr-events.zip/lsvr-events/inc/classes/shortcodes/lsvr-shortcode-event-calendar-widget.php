<?php
/**
 * LSVR Event Calendar Widget Shortcode
 */
if ( ! class_exists( 'Lsvr_Shortcode_Event_Calendar_Widget' ) ) {
    class Lsvr_Shortcode_Event_Calendar_Widget {

        public static function shortcode( $atts = array(), $content = null, $tag = '' ) {

            // Merge default atts and received atts
            $args = shortcode_atts(
                array(
                    'title' => '',
                    'icon' => '',
                    'location' => 0,
                    'category' => 0,
                    'split_multiday' => false,
                    'year_month' => '',
                    'more_label' => '',
                    'id' => '',
                    'className' => '',
                    'editor_view' => false,
                ),
                $atts
            );

            // Check if editor view
            $editor_view = true === $args['editor_view'] || '1' === $args['editor_view'] || 'true' === $args['editor_view'] ? true : false;

            // Element class
            $class_arr = array( 'widget shortcode-widget lsvr_event-calendar-widget lsvr_event-calendar-widget--shortcode' );
            if ( true === $editor_view ) {
                array_push( $class_arr, 'lsvr_event-calendar-widget--editor-view' );
            }
            if ( ! empty( $args['className'] ) ) {
                array_push( $class_arr, $args['className'] );
            }

            ob_start(); ?>

            <?php the_widget( 'Lsvr_Widget_Event_Calendar', array(
                'title' => $args['title'],
                'location' => $args['location'],
                'category' => $args['category'],
                'split_multiday' => $args['split_multiday'],
                'year_month' => $args['year_month'],
                'more_label' => $args['more_label'],
                'editor_view' => $args['editor_view'],
            ), array(
                'before_widget' => '<div' . ( ! empty( $args['id'] ) ? ' id="' . esc_attr( $args['id'] ) . '"' : '' ) . ' class="' . esc_attr( implode( ' ', $class_arr ) ) . '"><div class="widget__inner">',
                'after_widget' => '</div></div>',
                'before_title' => ! empty( $args['icon'] ) ? '<h3 class="widget__title widget__title--has-icon"><span class="widget__title-icon ' . esc_attr( $args['icon'] ) . '" aria-hidden="true"></span>' : '<h3 class="widget__title">',
                'after_title' => '</h3>',
            )); ?>

            <?php return ob_get_clean();

        }

        // Shortcode params
        public static function lsvr_shortcode_atts() {
            return array_merge( array(

                // Title
                array(
                    'name' => 'title',
                    'type' => 'text',
                    'label' => esc_html__( 'Title', 'lsvr-events' ),
                    'description' => esc_html__( 'Title of this section.', 'lsvr-events' ),
                    'default' => esc_html__( 'Upcoming Events', 'lsvr-events' ),
                    'priority' => 10,
                ),

                // Location
                array(
                    'name' => 'location',
                    'type' => 'taxonomy',
                    'tax' => 'lsvr_event_location',
                    'label' => esc_html__( 'Location', 'lsvr-events' ),
                    'description' => esc_html__( 'Display events only from a certain location.', 'lsvr-events' ),
                    'priority' => 20,
                ),

                // Category
                array(
                    'name' => 'category',
                    'type' => 'taxonomy',
                    'tax' => 'lsvr_event_cat',
                    'label' => esc_html__( 'Category', 'lsvr-events' ),
                    'description' => esc_html__( 'Display events from a specific category.', 'lsvr-events' ),
                    'priority' => 30,
                ),

                // Split multiday
                array(
                    'name' => 'split_multiday',
                    'type' => 'checkbox',
                    'label' => esc_html__( 'Split Multiday Events', 'lsvr-events' ),
                    'description' => esc_html__( 'Display multiday events under each day of the event duration.', 'lsvr-events' ),
                    'default' => false,
                    'priority' => 40,
                ),

                // Year - month
                array(
                    'name' => 'year_month',
                    'type' => 'text',
                    'label' => esc_html__( 'Calendar Month', 'lsvr-events' ),
                    'description' => esc_html__( 'Display a specific month. Use "YYYY-MM" format. For example: 2020-08 for August 2020. Leave blank if you want to use the current month.', 'lsvr-events' ),
                    'default' => '',
                    'priority' => 50,
                ),

                // More label
                array(
                    'name' => 'more_label',
                    'type' => 'text',
                    'label' => esc_html__( 'More Link Label', 'lsvr-events' ),
                    'description' => esc_html__( 'Link to events archive. Leave blank to hide.', 'lsvr-events' ),
                    'default' => esc_html__( 'More events', 'lsvr-events' ),
                    'priority' => 60,
                ),

                // ID
                array(
                    'name' => 'id',
                    'type' => 'text',
                    'label' => esc_html__( 'Unique ID', 'lsvr-events' ),
                    'description' => esc_html__( 'You can use this ID to style this specific element with custom CSS, for example.', 'lsvr-events' ),
                    'priority' => 70,
                ),

            ), apply_filters( 'lsvr_event_calendar_widget_shortcode_atts', array() ) );
        }

    }
}
?>